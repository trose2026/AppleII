
import SpriteKit
import UIKit
import SwiftUI
import PlaygroundSupport

import Foundation

// a text view to print the screen to
public class TextMonitor : UITextView, UITextViewDelegate {
    
}
